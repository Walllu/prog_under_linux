// this function is available for third-party use
// prints an 2D array as a PGM image
void printImg(int size, unsigned char array[][size], int depth);
