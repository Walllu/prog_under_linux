// try to parse input appropriately
double validate_input (int argc , char * argv []);
